//Process.h:����һЩ���̲�����
//
//
#ifndef _PROCESS_
#define _PROCESS_

#include <stdio.h>
#include <windows.h>
#include <TlHelp32.h>
#include <PSAPI.H>
#pragma comment(lib,"User32.lib")
#pragma comment(lib,"psapi.lib")
#pragma comment(lib,"advapi32.lib")

#define STATUS_SUCCESS ((NTSTATUS)0x00000000L)
#define STATUS_INFO_LENGTH_MISMATCH  ((NTSTATUS)0xC0000004L)

typedef LONG NTSTATUS;

typedef struct _UNICODE_STRING {
	USHORT  Length;
	USHORT  MaximumLength;
	PWSTR  Buffer;
} UNICODE_STRING, *PUNICODE_STRING;

//ϵͳģ����Ϣ
typedef struct _SYSTEM_MODULE_INFORMATION { 
	ULONG Reserved[2];
	PVOID Base;
	ULONG Size;
	ULONG Flags;
	USHORT Index;
	USHORT Unknown;
	USHORT LoadCount;
	USHORT ModuleNameOffset;
	CHAR ImageName[256];
} SYSTEM_MODULE_INFORMATION, *PSYSTEM_MODULE_INFORMATION;

//���ϵͳģ���б�
typedef struct _SystemModuleList{
	ULONG ulCount;
	SYSTEM_MODULE_INFORMATION smi[1];
} SYSTEMMODULELIST, *PSYSTEMMODULELIST;

typedef enum _THREAD_STATE{
	StateInitialized,
	StateReady,
	StateRunning,
	StateStandby,
	StateTerminated,
	StateWait,
	StateTransition,
	StateUnknown
} THREAD_STATE;

typedef enum _KWAIT_REASON {
	Executive,
	FreePage,
	PageIn,
	PoolAllocation,
	DelayExecution,
	Suspended,
	UserRequest,
	WrExecutive,
	WrFreePage,
	WrPageIn,
	WrPoolAllocation,
	WrDelayExecution,
	WrSuspended,
	WrUserRequest,
	WrEventPair,
	WrQueue,
	WrLpcReceive,
	WrLpcReply,
	WrVirtualMemory,
	WrPageOut,
	WrRendezvous,
	Spare2,
	Spare3,
	Spare4,
	Spare5,
	Spare6,
	WrKernel
} KWAIT_REASON;

typedef struct _VM_COUNTERS {
	ULONG PeakVirtualSize;
	ULONG VirtualSize;
	ULONG PageFaultCount;
	ULONG PeakWorkingSetSize;
	ULONG WorkingSetSize;
	ULONG QuotaPeakPagedPoolUsage;
	ULONG QuotaPagedPoolUsage;
	ULONG QuotaPeakNonPagedPoolUsage;
	ULONG QuotaNonPagedPoolUsage;
	ULONG PagefileUsage;
	ULONG PeakPagefileUsage;
} VM_COUNTERS, *PVM_COUNTERS;

typedef struct _CLIENT_ID
{
	ULONG PID;
	ULONG TID;
}CLIENT_ID,*PCLIENT_ID;

typedef struct _SYSTEM_THREADS {
	LARGE_INTEGER KernelTime;
	LARGE_INTEGER UserTime;
	LARGE_INTEGER CreateTime;
	ULONG WaitTime;
	PVOID StartAddress;
	CLIENT_ID ClientId;
	//KPRIORITY Priority;
	LONG Priority;
	//KPRIORITY BasePriority;
	LONG BasePriority;
	ULONG ContextSwitchCount;
	THREAD_STATE dwState;
	//DWORD dwState;
	KWAIT_REASON dwWaitReason;
	//DWORD dwWaitReason;
} SYSTEM_THREADS, *PSYSTEM_THREADS;

typedef struct _SYSTEM_PROCESSES { // Information Class 5
	ULONG NextEntryDelta;
	ULONG ThreadCount;
	ULONG Reserved1[6];
	LARGE_INTEGER CreateTime;
	LARGE_INTEGER UserTime;
	LARGE_INTEGER KernelTime;
	UNICODE_STRING ProcessName;
	//KPRIORITY BasePriority;
	LONG BasePriority;
	ULONG ProcessId;
	ULONG InheritedFromProcessId;
	ULONG HandleCount;
	ULONG Reserved2[2];
	VM_COUNTERS VmCounters;
	IO_COUNTERS IoCounters; // Windows 2000 only
	SYSTEM_THREADS Threads[1];
} SYSTEM_PROCESSES, *PSYSTEM_PROCESSES;

//����NtQuerySystemInformation����ԭ��
typedef ULONG (WINAPI *NtQuerySystemInformation)(
	IN ULONG SysInfoClass,
	IN OUT PVOID SystemInformation,
	IN ULONG SystemInformationLength,
	OUT PULONG nRet
	);

//����NtQueryInformationThread����ԭ��
typedef ULONG (WINAPI *NtQueryInformationThread)( 
	IN   HANDLE   ThreadHandle, 
	IN   ULONG   ThreadInformationClass, 
	OUT  PVOID   ThreadInformation, 
	IN   ULONG   ThreadInformationLength, 
	OUT  PULONG   ReturnLength   OPTIONAL 
	);

//��ȡ���̵�״̬
//����0����ʾ�����쳣
//����1����ʾ���̴��ڹ���״̬
//����2����ʾ����û�б�����
DWORD GetProcessState(ULONG ulPID);

//��ȡ���̵�״̬
//����0����ʾ�����쳣
//����1����ʾ�̴߳��ڹ���״̬
//����2����ʾ�߳�û�б�����
DWORD GetThreadState(ULONG ulPID,ULONG ulTID);

#endif //_PROCESS_