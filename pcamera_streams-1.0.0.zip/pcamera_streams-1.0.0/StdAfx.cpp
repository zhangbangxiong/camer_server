// stdafx.cpp : source file that includes just the standard includes
//	pcamera_streams.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

//#import "c:\Program Files\Common Files\System\ado\msado15.dll" 
//no_namespace rename("EOF", "adoEOF") rename("BOF", "adoBOF") 

