﻿// pcamera_streamsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "pcamera_streams.h"
#include "pcamera_streamsDlg.h"
#include "list.h"
#include "zlog.h"
#include "cjson.h"
#include <sys/stat.h>
#include <io.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <stddef.h>
#include <io.h>    
#include <fcntl.h>  
#include <iostream>  
#include <windows.h>  
#include <tlhelp32.h>  
#include <vector>
#include <Winternl.h>
#include <Sensapi.h>
#pragma comment(lib, "Sensapi.lib")
#pragma comment(lib, "zlog.lib")

using namespace std; 
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
FILE *logfile = NULL;
int  isdebug   = 0;
int	 server_id = -1;
char server_ip[32] = {0};
int  server_port = -1;
int  pos = -1;//左上 pos=0 右上 pos=1
char propath[255] = {0}; //MAX_PATH是Win32定义的一个宏，表示Windows允许的最大路径255;
CString logo_path;  

#define	s_len			16
#define	b_len			128
#define MD5_LEN			36
#define	LEN_EVENTID		64
#define	LEN_PARAM		64
#define	LEN_OBDID		32
#define	LEN_TOKEN		128
#define	LEN_VIDEO		128
#define MAX_BUFFER_SZIE 1024*1024

#define INPUT_BUFFER_SIZE 1024
#define NOMARL_BUFFER_SIZE 256
#define BUFFER_SIZE 128
#define DATA_SIZE 512
#define LOCAL_PRE "rtmp://192.168.102.248:1935"

struct list_head task_list;
HANDLE  m_pthreadmutex;
zlog_category_t *zc = NULL;

typedef struct Handle_control
{
    CProgressCtrl *myProCtrl;
	CWnd  *pWnd;
	CWnd  *txt;
	char str[128];
	int status;
	int step;
}HANDLECONTROL;

typedef struct stream_info
{
	struct list_head list;
	char sh[b_len];
	char stream_id[b_len];
	char stream_name[b_len];
	char out_stream_addr[b_len];
	char in_stream_addr[b_len];
	char protocol[s_len];
	char logo[b_len];
	char encode[s_len];
	int  hasaudio;
	char  bitrate[s_len];
	char  frame_rate[s_len];
	char  width[s_len];
	char  height[s_len];
	char  updatetimes[b_len];
	int  status;
	int   pid;
	long t1;
	long t2;
	int threadexit;
	HANDLE readfd;
	HANDLE threadhd;
	PROCESS_INFORMATION *pi;
	HANDLECONTROL *handle;
	int handle_num;
	HANDLE  m_pthreadmutex;    
    HANDLE  m_pthreadevent;  
}STREAMINFO;

typedef struct Config{
    char id[16];
    char ffmpeg[b_len];
    char sh[b_len];
    char kill_sh[b_len];
    char log_path[b_len];
}config_t;


int thread_nums = 0;
int stream_nums = 0;
config_t _config;
HANDLE infohd;
int info_thread_quit = 0;
HANDLECONTROL handle[6];

void InitConsoleWindow()    
{    
    AllocConsole();    
    HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);    
    int hCrt = _open_osfhandle((long)handle,_O_TEXT);    
    FILE * hf = _fdopen( hCrt, "w" );    
    *stdout = *hf;    
}  
// 判断文件或文件夹是否存在
BOOL IsPathExist(const CString & csPath)
{
    int nRet = _taccess(csPath, 0);
    return 0 == nRet || EACCES == nRet;
}

int get_available_handle()
{
	int i = 0;
	for (;i < 6; i++)
		if (handle[i].status == 0)
			return i;

	return -1;
}
int timeGetTime()
{
	 time_t timep;
     time(&timep);
	 return timep;
}

DWORD WinExecAndWait32(LPCTSTR lpszAppPath, LPCTSTR lpParameters, LPCTSTR lpszDirectory, DWORD dwMilliseconds,BOOL bIsWait,int nShow) 
{
	SHELLEXECUTEINFO ShExecInfo = {0};
	ShExecInfo.cbSize = sizeof(SHELLEXECUTEINFO);
	ShExecInfo.fMask	= SEE_MASK_NOCLOSEPROCESS;
	ShExecInfo.hwnd = NULL;
	ShExecInfo.lpVerb = NULL;
	ShExecInfo.lpFile = lpszAppPath; 
	ShExecInfo.lpParameters = lpParameters; 
	ShExecInfo.lpDirectory = lpszDirectory;
	ShExecInfo.nShow = nShow;	//SW_SHOW
	ShExecInfo.hInstApp = NULL; 
	ShellExecuteEx(&ShExecInfo);

	if ( ShExecInfo.hProcess == NULL)
		return 1;

	if ( !bIsWait )
		return 0;

	if (WaitForSingleObject(ShExecInfo.hProcess, dwMilliseconds) == WAIT_TIMEOUT)
	{ 
		TerminateProcess(ShExecInfo.hProcess, 0);
		return 1; 
	}

	DWORD dwExitCode;
	BOOL bOK = GetExitCodeProcess(ShExecInfo.hProcess, &dwExitCode);
	ASSERT(bOK);

	return dwExitCode;
}

int CheckNetIsOK(const CString sUpdateIP)
{
    //Judge Network is Connected
    int nCount = 1;
    do 
    {
        DWORD dw;
		int n = IsNetworkAlive(&dw);
		zlog_info(zc, "IsNetworkAlive n = %d", n);
        if(!IsNetworkAlive(&dw))
        {
			zlog_info(zc, "IsNetwork is not Alive");
            return -1;
        }
        else
        {
			break;
        }
    } while (nCount <4);

    DWORD n = WinExecAndWait32(_T("ping.exe"), sUpdateIP + " -n 2"/*sCmdPara*/, NULL, 10000, 0, 0);
    if (n == 0)
    {
		zlog_info(zc, "网络连接正常");
        return 1;
    }
    else
    {
        CString sNetWorkConnect;
        sNetWorkConnect.Format("网络连接正常, Ping:%s 失败, 请检测此IP对应的服务器是否正常工作", sUpdateIP);
		zlog_info(zc, "网络连接正常, Ping:%s 失败, 请检测此IP对应的服务器是否正常工作");
        //m_recvCtrl.SetWindowText(sNetWorkConnect);
        return 0;
    }
}
 
static int _connect(char *ip, int port)
{
	WORD wVersionRequested;    
	WSADATA wsaData;    
	int err;    
	wVersionRequested = MAKEWORD(1, 1);
    
	err = WSAStartup(wVersionRequested, &wsaData);    
	if(err != 0)    
	{   
		perror("WSAStartup error");    
	}

    struct sockaddr_in addr;
    int skt;

    skt = socket(AF_INET, SOCK_STREAM, 0);

    ///zlog_info(zc, "connetc ip = %s skt = %d", ip,skt);
    memset(&addr, 0, sizeof(addr) );
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr(ip);
    addr.sin_port = htons(port);
    ///zlog_info(zc, "connetc port = %d", port);

    connect(skt, (struct sockaddr *)&addr, sizeof(addr));
    return skt;
}

CString GetHostbyName(const char * HostName)
{
    CString strIPAddress=_T("");
    int WSA_return;
    WSADATA WSAData;

    WSA_return=WSAStartup(0x0202,&WSAData);
    /* 结构指针 */ 
    HOSTENT *host_entry;
    if(WSA_return==0)
    {
        /* 即要解析的域名或主机名 */
        host_entry=gethostbyname(HostName);
        if(host_entry!=0)
        {
            strIPAddress.Format(_T("%d.%d.%d.%d"),
                (host_entry->h_addr_list[0][0]&0x00ff),
                (host_entry->h_addr_list[0][1]&0x00ff),
                (host_entry->h_addr_list[0][2]&0x00ff),
                (host_entry->h_addr_list[0][3]&0x00ff));
        }
    }
    return strIPAddress;
}

//getcamera?server_id=%s&&ip=%s
int send_msg(char *ip, int port, char *data, char *res)
{
        char mess[256] = {0};
		int pos = 0;
        int val = 0;
        int mess_len = 0;
        char res1[1024*10] = {0};
        int skt = _connect(ip, port);
		if (skt <= 0)
		{
			zlog_info(zc, "connect failed");
			return -1;
		}

        mess_len = sprintf(mess, "POST /getcamera?%s HTTP/1.0\r\n", data);
        mess_len += sprintf(mess + mess_len, "Host:%s\r\n", ip);
        mess_len += sprintf(mess + mess_len, "Content-Type:application/x-www-form-urlencoded\r\n");
        mess_len += sprintf(mess + mess_len, "Content-Length:%d\r\n\r\n", (int)strlen(data));
        mess_len += sprintf(mess + mess_len, "%s", data);

		//zlog_info(zc, "mess = %s", mess);
        val = send(skt, mess, mess_len, 0);
        if (val < 0)
        {
                goto END;
        }

		while (1)
		{
			val = recv(skt, res1+pos, 2048, 0);
			//printf("len = %d, res1 = %s, val = %d", strlen(res1), res1, val);
			if (val <= 0)
			{
				goto END;
			}
			else 
			{
				pos += val;
				//if (strlen(res1) > 4)
				//	strcpy(res, strstr(res1, "\r\n\r")+4);
				//printf("len = %d, res = %s", strlen(res), res);
			}

			if (val < 2048)
				break;
		}

		if (strlen(res1) > 4)
		{
			strcpy(res, strstr(res1, "\r\n\r\n")+4);
			zlog_info(zc, "len = %d, res = %s", strlen(res), res);
		}
END:
        closesocket (skt);
        return val;
}

long _gettime_s()       //unit: s
{
	struct tm *ptr = NULL;
	time_t lt;
	lt =time(NULL);
    return lt;
}

int get_camero_status(char *path, char *stream_id)
{
        struct stat buf;
        int  result = 0;
        char file[255] = {0};

        sprintf(file, "%s/%s.log", path, stream_id);
        if (access(file, 0) == -1)
        {
               return -1;
        }

        result = stat(file, &buf);
        if ( result != 0 )
        {
                return -2;
        }
        else
        {
                long now_time = _gettime_s();
                if (now_time - buf.st_atime < 30)
                        return 0;
                int dif_time = _gettime_s() - buf.st_mtime;
                if (dif_time < 5)
                        return 1;
                else
                        return 0;
        }
}

bool killProcess(PROCESS_INFORMATION *processInfo){  
    DWORD processId = processInfo->dwProcessId;  
    PROCESSENTRY32 processEntry = {0};  
    processEntry.dwSize = sizeof(PROCESSENTRY32);  
    //给系统内的所有进程拍一个快照  
    HANDLE handleSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);  
     
    //遍历每个正在运行的进程  
    if( Process32First(handleSnap, &processEntry) ){  
        BOOL isContinue = TRUE;  
  
        //终止子进程  
        do{  
            if( processEntry.th32ParentProcessID == processId ){  
                HANDLE hChildProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processEntry.th32ProcessID);  
                if( hChildProcess ){  
                    TerminateProcess(hChildProcess, 0);  
                    CloseHandle(hChildProcess);  
                }  
            }  
            isContinue = Process32Next(handleSnap, &processEntry);  
        }while( isContinue );  
          
        HANDLE hBaseProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processId);  
        if( hBaseProcess ){  
            TerminateProcess(hBaseProcess, 0);  
            CloseHandle(hBaseProcess);  
        }  
    }  
    DWORD exitCode = 0;  
    GetExitCodeProcess(processInfo->hProcess, &exitCode);  
    zlog_info(zc, "exitCode=%d", exitCode);  
    if( exitCode == STILL_ACTIVE ){  
        return false;  
    }  
    return true;  
}  

void kill_process(int pid)
{
	HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, pid);

	if (hProcess != NULL)
	{
		BOOL bOkey = TerminateProcess(hProcess, 0);
		if(bOkey)
		{
			WaitForSingleObject(hProcess, 1000);
			CloseHandle(hProcess);
			hProcess = NULL;
		}
	}
}

int run_command(struct stream_info *info, char *argv, char *outfile, int *timelen, int *video_width, int *video_height)
{
	return 0;
}

#define CODEC_VIDEO_STRING_0  "%s %s %s %s %s %s %s %s %d %s %s %s %s"
#define CODEC_JPEG_STRING   "%s -i %s -o %s -n 20 -@ %s"
#define TSCUT_STRING        "%s -i %s -d 10 -o %s -s %s -d 10 -x %s"
void *start_gome_transcoder(void *params)
{
    char  argv[INPUT_BUFFER_SIZE]    = {0};
    char  outfile[BUFFER_SIZE]       = {0};
    char  outfullfile[NOMARL_BUFFER_SIZE]    = {0};

	int   video_time_lenth = 0;
	int   video_width      = 0;
	int   video_height     = 0;
	struct stream_info *info = NULL;

	if(params != NULL)
	{
		info = (struct stream_info *)params;
	}

	char log_path[256] = {0};
	sprintf(log_path, "%s/%s.log", _config.log_path,info->stream_id);
		
	memset(outfullfile, 0, NOMARL_BUFFER_SIZE);
	memset(outfile, 0, BUFFER_SIZE);
	memset(argv, 0, INPUT_BUFFER_SIZE);

	zlog_info(zc, "info->stream_id = %s", info->stream_id);
    sprintf(argv, CODEC_VIDEO_STRING_0, 
		_config.sh, 		_config.ffmpeg, info->in_stream_addr, 
		info->protocol, 	info->encode, 	info->bitrate,
		info->width, 		info->height, 	0, 
		info->out_stream_addr,	info->logo, 	_config.log_path,
		info->stream_id);

	/*********************************************************
 			start codec
	********************************************************/
	run_command(info, argv, outfile, &video_time_lenth, &video_width, &video_height);

	info->status = 0;
	//pthread_mutex_lock(&threadsmtx);
	//thread_nums --;
    //pthread_mutex_unlock(&threadsmtx);
	//pthread_exit(0);  
	return NULL;
}

BOOL IsProcessExist(TCHAR* ptzProcessName, int id)  
{  
    BOOL bRet = FALSE;  
    HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);  
    if( INVALID_HANDLE_VALUE == hProcessSnap )  
    {  
        return FALSE;  
    }  
  
    PROCESSENTRY32 pe32 = { 0 };  
    pe32.dwSize = sizeof( PROCESSENTRY32 );  
    if( !Process32First( hProcessSnap, &pe32 ) )  
    {  
        CloseHandle( hProcessSnap );   
        return FALSE;  
    }  
  
    do  
    {  		
		if( !_tcscmp(pe32.szExeFile, ptzProcessName) && (int)pe32.th32ProcessID == id)  
        {  
			zlog_info(zc, "name = %s, id = %d, s_id = %d", pe32.szExeFile, pe32.th32ProcessID, id);
			zlog_info(zc, "-----------------------------------------------");
            bRet = TRUE;  
            break;  
        }  
    } while( Process32Next(hProcessSnap, &pe32));  
    CloseHandle(hProcessSnap);  
      
    return bRet;  
}  

int stop_pro(struct stream_info *info)
{
	zlog_info(zc, "[%d]stop_pro pro [%d] is not existed", info->stream_id,info->pid);
	info->threadexit = 1;
	zlog_info(zc, "stop_pro read file error");
	DWORD processId = info->pid;
	kill_process(processId);
	TerminateProcess(info->pi->hProcess, 300);

	//info->handle->myProCtrl->ShowWindow(SW_HIDE);
	//info->handle->pWnd->ShowWindow(SW_HIDE);
	//info->handle->txt->ShowWindow(SW_HIDE);
 
	handle[info->handle_num].status = 0;
	char arg[256] = {0};
	zlog_info(zc, "stop_pro info->pid = %d",info->pid);
	//sprintf(arg, "taskkill /F /PID %d", processId);
	//system(arg);
	zlog_info(zc, "stop_pro taskkill pid [%d]", processId);
	WaitForSingleObject(info->threadhd,100); 
	zlog_info(zc, "stop_pro WaitForSingleObject [%d]", processId);
	CloseHandle(info->threadhd);
	CloseHandle(info->readfd);
	info->status = 0;

	if (info->handle != NULL)
	{
		info->handle->status = 0;
		info->handle = NULL;
	}

	list_del(&info->list);

	if(info != NULL)
	{
		free(info);
		info = NULL;
	}
	return 0;
}

DWORD WINAPI get_log(LPVOID param)
{
	struct stream_info *info  = NULL;	
	DWORD  nread = 0;
	char buf[4096] = {0};
	bool rc = FALSE;
	info = (struct stream_info *)param;
	OVERLAPPED overlap;
	//while(1)
	//{
	//	printf("read start ---");
	//rc = ReadFile(info->readfd,buf,4096, &nread ,NULL);
	//info->t2 = _gettime_s();
	//}
	while (1)
	{
		//printf("read start ---");
		if (info->threadexit)
		{
			zlog_info(zc, "stream [%s] thread exit", info->stream_id);
			break;
		}
		memset(&overlap, 0, sizeof(overlap));
		rc = ReadFile(info->readfd,buf,4096, &nread ,&overlap);
		if (rc)
		{
			 //the data was read successfully
			zlog_info(zc, "[%s] [%d]read ok buf = %s", info->stream_id, strlen(buf), buf);
			if (strlen(buf) > 2)
				info->t2 = _gettime_s();
		}
		else
		{
			//printf("read failed");
			if (GetLastError() == ERROR_IO_PENDING)
			{
                WaitForSingleObject(info->readfd,2000);
                rc = GetOverlappedResult(info->readfd, &overlap, &nread,  FALSE);
			}
			else
			{
			}
		}
		memset(buf, 0, 4096);
	}
	info->threadexit = 2;
	//ReadFile(info->readfd, buffer, 40959, &nread, NULL);
	
	return 0;
}

//DWORD WINAPI  read_db(LPVOID lpParameter)
DWORD WINAPI get_camera_info(LPVOID param)
//int  get_camera_info()
{
LOOP:
	struct _stat ms;
    _stat("mylog.log", &ms);
    int size = ms.st_size;
	zlog_info(zc, "mylog file size = %d", size);
	if (size > 200*1024*1024)
	{
		zlog_fini();
		::DeleteFile("mylog.log");
		int rc = zlog_init("log.conf");
		if (rc) 
		{
			printf("init failed");
			return -1;
		}

		zc = zlog_get_category("my_cat");
		if (!zc) 
		{
			printf("get cat fail");
			zlog_fini();
			return -1;
		}
	}

	printf("...\n");
	logfile = fopen("log.dat", "wb+");
	if (logfile)
	{
	    fwrite("===", 3, 1, logfile);
		fflush(logfile);
	    fclose(logfile);
		logfile = NULL;
	}

	zlog_info(zc, "info_thread_quit = %d",info_thread_quit);
	if (info_thread_quit)
		return 0;

	char res[1024*10] = {0};
	char str[128]   = {0};
	sprintf(str, "server_id=%d&&ip=%s", server_id, server_ip);
	send_msg(server_ip, server_port, str, res);
	if (strlen(res) < 4 || strstr(res, "result") != NULL)
	{
		zlog_info(zc, "do not get camera info");
		Sleep(3000);
		goto LOOP;
	}

	zlog_info(zc, "get_camera_info res = %s", res);
	
    struct stream_info *info  = NULL;
    struct stream_info *_info = NULL;

	WaitForSingleObject(m_pthreadmutex,INFINITE);
    list_for_each_entry_safe(struct stream_info, info, _info, &task_list, list)
    {
   		if (info->status == 1 && info->pi != NULL)
	    {
			info->t1 = _gettime_s();
			zlog_info(zc, "[%s]processId = %d", info->stream_id, info->pid);
			if (strcmp(info->protocol, "p2p") != 0 && FALSE == IsProcessExist("ffmpeg.exe", info->pid))
			{				
				zlog_info(zc, "[%d]pro [%d] is not existed", info->stream_id, info->pid);
				info->threadexit = 1;
				zlog_info(zc, "[%d]read file error", info->stream_id);
				DWORD processId = info->pid;
				kill_process(processId);
				handle[info->handle_num].status = 0;
				TerminateProcess(info->pi->hProcess, 300);
				//info->handle->myProCtrl->ShowWindow(SW_HIDE);
				//info->handle->pWnd->ShowWindow(SW_HIDE);
				//info->handle->txt->ShowWindow(SW_HIDE);
				char arg[256] = {0};
				zlog_info(zc, "info->pid = %d",info->pid);
				//sprintf(arg, "taskkill /F /PID %d", processId);
				//system(arg);
				zlog_info(zc, "taskkill pid [%d]", processId);
				//WaitForSingleObject(info->threadhd,100); 
				while (info->threadexit == 1)
				{
				    Sleep(100);
				}
				zlog_info(zc, "00 WaitForSingleObject [%d] info->threadexit = %d", processId, info->threadexit);
				CloseHandle(info->threadhd);
				CloseHandle(info->readfd);
				zlog_info(zc, "01 WaitForSingleObject [%d]", processId);
				//if (info->handle != NULL)
				//{
				//	info->handle->status = 0;
				//	info->handle = NULL;
				//}
				zlog_info(zc, "02 WaitForSingleObject [%d]", processId);
			    list_del(&info->list);

			    if(info != NULL)
			    {
				    free(info);
				    info = NULL;
			    }
				zlog_info(zc, "03 WaitForSingleObject [%d]", processId);
			}
			else if (strcmp(info->protocol, "p2p") == 0 && FALSE == IsProcessExist("p2p.exe", info->pid))
			{
				zlog_info(zc, "[%d]p2p [%d] is not existed", info->stream_id, info->pid);
				info->threadexit = 1;
				DWORD processId = info->pid;
				kill_process(processId);
				//info->handle->myProCtrl->ShowWindow(SW_HIDE);
				//info->handle->pWnd->ShowWindow(SW_HIDE);
				//info->handle->txt->ShowWindow(SW_HIDE);
				TerminateProcess(info->pi->hProcess, 300);
				char arg[256] = {0};
				zlog_info(zc, "[%d]kill info->pid = %d",info->stream_id,info->pid);
				//sprintf(arg, "taskkill /F /PID %d", processId);
				//system(arg);
				zlog_info(zc, "taskkill pid [%d]", processId);
				WaitForSingleObject(info->threadhd,100); 
				zlog_info(zc, "WaitForSingleObject [%d]", processId);
				CloseHandle(info->threadhd);
				CloseHandle(info->readfd);

				//if (info->handle != NULL)
				//{
				//	info->handle->status = 0;
				//	info->handle = NULL;
				//}
			    list_del(&info->list);

			    if(info != NULL)
			    {
				    free(info);
				    info = NULL;
			    }
			}
			else if (strcmp(info->protocol, "p2p") != 0)
			{
				zlog_info(zc, "[%s]info->t2 = %ld", info->stream_id, info->t2);
				zlog_info(zc, "[%s]info->t1 = %ld", info->stream_id, info->t1);
				if ((info->t1 - info->t2) > 10)
				{
					info->threadexit = 1;
					zlog_info(zc, "read file error");
					DWORD processId = info->pid;
					kill_process(processId);
					//killProcess(info->pi);
					//info->handle->myProCtrl->ShowWindow(SW_HIDE);
					//info->handle->pWnd->ShowWindow(SW_HIDE);
					//info->handle->txt->ShowWindow(SW_HIDE);
					handle[info->handle_num].status = 0;
					TerminateProcess(info->pi->hProcess, 300);
					char arg[256] = {0};
					zlog_info(zc, "[%d]kill info->pid = %d",info->stream_id,info->pid);
					//sprintf(arg, "taskkill /F /PID %d", processId);
					//system(arg);					
					WaitForSingleObject(info->threadhd,1000);  
					CloseHandle(info->threadhd);
					CloseHandle(info->readfd);
					//TerminateThread(info->threadhd, 0);
					info->status = 0;
					//if (info->handle != NULL)
					//{
					///	info->handle->status = 0;
					//	info->handle = NULL;
					//}
					list_del(&info->list);
					if(info != NULL)
					{
						free(info);
						info = NULL;
					}

				}

				//ClearCommError(info->readfd, lpErrors, lpStat);
				/*
				if (ReadFile(info->readfd, buffer, 40959, &nread, &overlap) == NULL)
				{
					if (nread == 0)
					{
						list_del(&info->list);
						if(info != NULL)
						{
							free(info);
							info = NULL;
						}
					}
				}
				else
					printf("nread = %d", nread);
					*/
			}			
		}   
	}
	ReleaseMutex(m_pthreadmutex);
	cJSON * pjson,*psub,*psub1 ;
    int icount=0;
    pjson = cJSON_Parse(res);  /* 解析 json 放入 pJson*/
    if(NULL == pjson)
    {
		zlog_info(zc, "pjson is null");
        Sleep(1000);
		goto LOOP;
    }
    icount = cJSON_GetArraySize(pjson);
	zlog_info(zc, "icount ======== %d", icount);
	{
    	for (int loop = 0; loop < icount; loop ++)
		{
		    psub = cJSON_GetArrayItem(pjson, loop);
            psub1 = cJSON_GetObjectItem(psub, "status");
            if (atoi(psub1->valuestring) != 0)
			{
				int status = 0;

                info  = NULL;
                _info = NULL;

                list_for_each_entry_safe(struct stream_info, info, _info, &task_list, list)
                {
					psub1 = cJSON_GetObjectItem(psub, "stream_id");	
					if (strcmp(info->stream_id, psub1->valuestring) == 0)
					{
						status = info->status;
						if (strcmp(info->width, cJSON_GetObjectItem(psub, "width")->valuestring) != 0  
						  ||strcmp(info->height, cJSON_GetObjectItem(psub, "height")->valuestring) != 0 
						  ||strcmp(info->bitrate, cJSON_GetObjectItem(psub, "bitrate")->valuestring) != 0
						  ||strcmp(info->updatetimes, cJSON_GetObjectItem(psub, "updatetimes")->valuestring) != 0) 
					    {
							zlog_info(zc, "[%d] stop pro", info->stream_id);
							stop_pro(info);
							status = 0;
					    }
						 
						zlog_info(zc, "[%d]info->status = %d", info->stream_id, info->status);
						break;
					}
                }
		
				if (status)
					continue;

                struct stream_info *stream_news = NULL;
                stream_news = (struct stream_info *)malloc(sizeof(struct stream_info));

				psub1 = cJSON_GetObjectItem(psub, "stream_id");
				memset(stream_news->stream_id, 0, sizeof(stream_news->stream_id));
                memcpy(stream_news->stream_id, psub1->valuestring, strlen(psub1->valuestring));

				psub1 = cJSON_GetObjectItem(psub, "logo");
                memset(stream_news->logo, 0, sizeof(stream_news->logo));
                memcpy(stream_news->logo, psub1->valuestring, strlen(psub1->valuestring));

                psub1 = cJSON_GetObjectItem(psub, "width");
                memset(stream_news->width, 0, sizeof(stream_news->width));
                memcpy(stream_news->width, psub1->valuestring, strlen(psub1->valuestring));

                psub1 = cJSON_GetObjectItem(psub, "height");
                memset(stream_news->height, 0, sizeof(stream_news->height));
                memcpy(stream_news->height, psub1->valuestring, strlen(psub1->valuestring));

                psub1 = cJSON_GetObjectItem(psub, "bitrate");
                memset(stream_news->bitrate, 0, sizeof(stream_news->bitrate));
                memcpy(stream_news->bitrate, psub1->valuestring, strlen(psub1->valuestring));

                psub1 = cJSON_GetObjectItem(psub, "encode");
                memset(stream_news->encode, 0, sizeof(stream_news->encode));
                memcpy(stream_news->encode, psub1->valuestring, strlen(psub1->valuestring));

                psub1 = cJSON_GetObjectItem(psub, "in_stream_addr");
                memset(stream_news->in_stream_addr, 0, sizeof(stream_news->in_stream_addr));
                memcpy(stream_news->in_stream_addr, psub1->valuestring, strlen(psub1->valuestring));
				//memcpy(stream_news->in_stream_addr, "D://five650hours.ts", strlen("D://five650hours.ts"));
                memset(stream_news->protocol, 0, sizeof(stream_news->protocol));
                if (strstr(stream_news->in_stream_addr, "rtsp://"))
                      memcpy(stream_news->protocol, "rtsp:", 4);
                else if (strstr(stream_news->in_stream_addr, "rtmp://") || strstr(stream_news->in_stream_addr, "http://"))
                      memcpy(stream_news->protocol, "rtmp", 4);
				else 
					  memcpy(stream_news->protocol, "p2p", 3);

                psub1 = cJSON_GetObjectItem(psub, "out_stream_addr");
                memset(stream_news->out_stream_addr, 0, sizeof(stream_news->out_stream_addr));
	            memcpy(stream_news->out_stream_addr, psub1->valuestring, strlen(psub1->valuestring));
				/*
				char *pp = strstr(stream_news->out_stream_addr,"41935");
				if (pp)
				{
					char channel_name[64] = {0};
					strcpy(channel_name, strchr(pp, '/')+1);
					printf("channel_name = %s\n", channel_name);
					memset(stream_news->out_stream_addr, 0, sizeof(stream_news->out_stream_addr));
					sprintf(stream_news->out_stream_addr, "%s/%s", LOCAL_PRE, channel_name);
					printf("stream_news->out_stream_addr = %s\n", stream_news->out_stream_addr);
				}*/

				psub1 = cJSON_GetObjectItem(psub, "updatetimes");
                memset(stream_news->updatetimes, 0, sizeof(stream_news->updatetimes));
                memcpy(stream_news->updatetimes, psub1->valuestring, strlen(psub1->valuestring));
				//memcpy(stream_news->out_stream_addr, "rtmp://172.25.4.41:41935/live/40002", strlen("rtmp://172.25.4.41:41935/live/40002"));

                zlog_info(zc, "id = %d, info->height = %s，stream_news->bitrate=%s",atoi(stream_news->stream_id), stream_news->height, stream_news->bitrate);
				
				STARTUPINFO si;  
				PROCESS_INFORMATION pi;  
				char appName[2048]= {0};
				char vf_str[128]  = {0};
				char in_put[128]  = {0};
				if (strcmp(stream_news->protocol, "p2p") != 0)
				{
					printf("logo_path = %s\n", logo_path);
					if (IsPathExist(logo_path))
					{
						if (pos == 1)//右上
						{
							zlog_info(zc, "logo is added at right");
							int height = atoi(stream_news->height)/10;
							sprintf(in_put, "-i %s -i %s", stream_news->in_stream_addr, logo_path);
							//sprintf(in_put, " -re -i D://five650hours.ts -i %s", logo_path);
							sprintf(vf_str, "-filter_complex [0:v]scale=-4:%s[movie];[1:v]scale=-1:%d[img1];[movie][img1]overlay=W-w-30:30",
								stream_news->height, height);
						}
						else//左上
						{
							zlog_info(zc, "logo is added at left");
							int height = atoi(stream_news->height)/10;
							sprintf(in_put, "-i %s -i %s", stream_news->in_stream_addr, logo_path);
							//sprintf(in_put, " -re -i D://five650hours.ts -i %s", logo_path);
							sprintf(vf_str, "-filter_complex [0:v]scale=-4:%s[movie];[1:v]scale=-1:%d[img1];[movie][img1]overlay=30:30",
								stream_news->height, height);
						}
					}
					else
					{
						sprintf(in_put, "-i %s ", stream_news->in_stream_addr);
						sprintf(vf_str, "-filter_complex scale=-4:%s", stream_news->height);
					}
					zlog_info(zc, "stream_news->bitrate = %d", atoi(stream_news->bitrate));
					if (atoi(stream_news->bitrate) == 1)
					{
						if (strstr(stream_news->in_stream_addr, "rtsp"))
							sprintf(appName, "ffmpeg.exe -stimeout 3000000  -i %s -c:v copy -an -f flv -y %s", stream_news->in_stream_addr, stream_news->out_stream_addr);
						else
							sprintf(appName, "ffmpeg.exe -i %s -c:v copy -an -f flv -y %s", stream_news->in_stream_addr, stream_news->out_stream_addr);
					}
					else
					{
						if (strstr(stream_news->in_stream_addr, "rtsp"))
							sprintf(appName, "ffmpeg.exe -stimeout 3000000  %s -preset veryfast -c:v libx264 -b:v %sk -r 25 %s -pix_fmt yuv420p -profile:v main -level 31 -g 125 -force_key_frames expr:gte(t,n_forced*5) -vsync 1 -an  -f flv -y %s", 
							in_put,stream_news->bitrate, vf_str, stream_news->out_stream_addr);
						else
							sprintf(appName, "ffmpeg.exe  %s -preset veryfast -c:v libx264 -b:v %sk -r 25 %s -pix_fmt yuv420p -profile:v main -level 31 -g 125 -force_key_frames expr:gte(t,n_forced*5) -vsync 1 -an  -f flv -y %s", 
							in_put,stream_news->bitrate, vf_str, stream_news->out_stream_addr);					
					}
				}
				else if (strcmp(stream_news->protocol, "p2p") == 0)
				{
					sprintf(appName, "p2p.exe %s %s", stream_news->in_stream_addr, stream_news->out_stream_addr);
				}
				zlog_info(zc, "appname = %s", appName);
				ZeroMemory(&si, sizeof(si));  
				ZeroMemory(&pi, sizeof(pi)); 

				SECURITY_ATTRIBUTES sa;
				HANDLE hRead,hWrite;

				sa.nLength = sizeof(SECURITY_ATTRIBUTES);
				sa.lpSecurityDescriptor = NULL;
				sa.bInheritHandle = TRUE;
				if (!CreatePipe(&hRead,&hWrite,&sa,0)) 
				{
					if (pjson)
						free(pjson);
					Sleep(1000);
					goto LOOP;
				} 
				si.cb = sizeof(STARTUPINFO);
				GetStartupInfo(&si); 
				si.hStdError = hWrite;            //把创建进程的标准错误输出重定向到管道输入
				si.hStdOutput = hWrite;           //把创建进程的标准输出重定向到管道输入
				si.wShowWindow = SW_HIDE;
				si.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
				//system(appName);

				if(CreateProcess(  
					NULL,   //  指向一个NULL结尾的、用来指定可执行模块的宽字节字符串  
					appName, // 命令行字符串  
					NULL, //    指向一个SECURITY_ATTRIBUTES结构体，这个结构体决定是否返回的句柄可以被子进程继承。  
					NULL, //    如果lpProcessAttributes参数为空（NULL），那么句柄不能被继承。<同上>  
					true,//    指示新进程是否从调用进程处继承了句柄。					
					NULL,  //  指定附加的、用来控制优先类和进程的创建的标  
					//CREATE_NEW_CONSOLE, // 新控制台打开子进程  
					//CREATE_SUSPENDED, //   子进程创建后挂起，直到调用ResumeThread函数  
					NULL, //    指向一个新进程的环境块。如果此参数为空，新进程使用调用进程的环境  
					NULL, //    指定子进程的工作路径  
					&si, // 决定新进程的主窗体如何显示的STARTUPINFO结构体  
					&pi  // 接收新进程的识别信息的PROCESS_INFORMATION结构体  
					))  
				{  
					stream_news->status = 1;
					stream_news->pi		= &pi;
					stream_news->pid    = stream_news->pi->dwProcessId;
					stream_news->readfd = hRead;

					zlog_info(zc, "create process success %d", stream_news->pi->dwProcessId);  
					stream_news->t1 = stream_news->t2 = _gettime_s();
					stream_news->threadexit = 0;
					//if (strcmp(stream_news->protocol, "p2p") == 0)
					stream_news->threadhd = CreateThread(NULL, 0, get_log, (void *)stream_news, 0, NULL);
					int n = get_available_handle();
					if (n>=0)
					{
						//stream_news->handle = &handle[n];
						stream_news->handle_num = n;
						strcpy(handle[n].str,stream_news->stream_id);
						handle[n].status  = 1;
						handle[n].step    = 0;
						zlog_info(zc, "n ============= %d handle[n].str = %s", n, handle[n].str);
						//stream_news->handle->myProCtrl->ShowWindow(SW_SHOW);
						//stream_news->handle->myProCtrl->SetRange(0,100); 
					}
					else
						stream_news->handle = NULL;
					//下面两行关闭句柄，解除本进程和新进程的关系，不然有可能不小心调用TerminateProcess函数关掉子进程
					stream_nums ++;
					CloseHandle(hWrite);
				}  
				else
				{  
					zlog_info(zc, "failed to create process");  
				}  
				list_add_tail(&stream_news->list, &task_list);
			}
			else
			{
                info  = NULL;
                _info = NULL;

				WaitForSingleObject(m_pthreadmutex,INFINITE);
                list_for_each_entry_safe(struct stream_info,info, _info, &task_list, list)
                {
					psub1 = cJSON_GetObjectItem(psub, "stream_id");
					if (strcmp(info->stream_id, psub1->valuestring) == 0)
					{
						if (info->status == 1 && info->pi != NULL)
						{
							printf("------------------------\n");
							printf("info->handle_num = %d\n", info->handle_num);
							//info->handle->myProCtrl->ShowWindow(SW_HIDE);
							//info->handle->pWnd->ShowWindow(SW_HIDE);
							//info->handle->txt->ShowWindow(SW_HIDE);
							handle[info->handle_num].status = 0;
							DWORD processId = info->pid;
				            kill_process(processId);
							TerminateProcess(info->pi->hProcess, 300);
							info->threadexit = 1;
							char arg[256] = {0};
							zlog_info(zc, "[%d]0001 info->pid = %d",info->stream_id, info->pid);
							//sprintf(arg, "taskkill /F /PID %d", processId);
							//system(arg);										
							WaitForSingleObject(info->threadhd,1000);  
							CloseHandle(info->threadhd);
							CloseHandle(info->readfd);
							info->status = 0;
							//if (info->handle != NULL)
							//{
							//	info->handle->status = 0;
							//	info->handle = NULL;
							//}
							list_del(&info->list);
							if(info != NULL)
							{
								free(info);
								info = NULL;
							}

						}                   	    
					}					
                }				
				ReleaseMutex(m_pthreadmutex);
			}

		}
	}

	if (pjson)
	{
		cJSON_Delete(pjson);
		pjson = NULL;
	}
	Sleep(5000);
	goto LOOP;

	return 0;
}

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPcamera_streamsDlg dialog

CPcamera_streamsDlg::CPcamera_streamsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPcamera_streamsDlg::IDD, pParent)
	, m_server_id(0)
{
	//{{AFX_DATA_INIT(CPcamera_streamsDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	//GetCurrentDirectory(255 , propath);
	//printf("propath = %s", propath);
    //GetModuleFileName(NULL,propath.GetBuffer(MAX_PATH),MAX_PATH);
    //int pos = propath.ReverseFind(_T("\\"));
	//printf("pos = %d", pos);
    //propath = propath.Left(pos);
	INIT_LIST_HEAD(&task_list);

	if (__argc <= 1)
		GetCurrentDirectory(255 , propath);
	else
		memcpy(propath, __argv[1], strlen(__argv[1]));
	
	ok_status = 0;
	printf("propath = %s", propath);

	//zlog_category_t *zc;
	char log_full_path[512] = {0};
	sprintf(log_full_path, "%s/log.conf", propath);
	int rc = zlog_init(log_full_path);
	if (rc) 
	{
		printf("init failed");
		return;
	}

	zc = zlog_get_category("my_cat");
	if (!zc) 
	{
		printf("get cat fail");
		zlog_fini();
		return;
	}

	zlog_info(zc, "pro starting ....");

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CPcamera_streamsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPcamera_streamsDlg)
	// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
	//DDX_Text(pDX, IDC_EDIT1, m_server_id);
}

BEGIN_MESSAGE_MAP(CPcamera_streamsDlg, CDialog)
	//{{AFX_MSG_MAP(CPcamera_streamsDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	//ON_EN_CHANGE(IDC_EDIT1, &CPcamera_streamsDlg::OnEnChangeEdit1)
	ON_WM_TIMER()
//	ON_BN_CLICKED(IDCANCEL, &CPcamera_streamsDlg::OnBnClickedCancel)
//	ON_BN_CLICKED(IDOK, &CPcamera_streamsDlg::OnBnClickedOk)
ON_WM_ERASEBKGND() 
ON_BN_CLICKED(IDYES, &CPcamera_streamsDlg::OnBnClickedYes)
ON_BN_CLICKED(ID_NETTEST, &CPcamera_streamsDlg::OnBnClickedYes2)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPcamera_streamsDlg message handlers

BOOL CPcamera_streamsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	//CString   str2   =   "27.223.92.102"; 
	//GetDlgItem(IDC_EDIT2)->SetWindowText(str2);

	//CString   str3   =   "4188 "; 
	//GetDlgItem(IDC_EDIT3)->SetWindowText(str3);

	//CString	 str4 = "请选择logo文件";//默认显示内容 
	//GetDlgItem(IDC_EDIT4)->SetWindowText(str4);
	CPcamera_streamsDlg::OnOK();

	CProgressCtrl *myProCtrl1 = (CProgressCtrl *)GetDlgItem(IDC_PROGRESS1);
	myProCtrl1->ShowWindow(SW_HIDE);
	CWnd  *pWnd1 = GetDlgItem(IDC_STATIC_C1);
	CWnd  *txt1  = GetDlgItem(IDC_STATIC1);
	pWnd1->ShowWindow(SW_HIDE);
	txt1->ShowWindow(SW_HIDE);
	handle[0].myProCtrl = myProCtrl1;
	handle[0].pWnd      = pWnd1;
	handle[0].txt       = txt1;
	

	CProgressCtrl *myProCtrl2 = (CProgressCtrl *)GetDlgItem(IDC_PROGRESS2);
	myProCtrl2->ShowWindow(SW_HIDE);
	CWnd  *pWnd2 = GetDlgItem(IDC_STATIC_C2);
	CWnd  *txt2  = GetDlgItem(IDC_STATIC2);
	pWnd2->ShowWindow(SW_HIDE);
	txt2->ShowWindow(SW_HIDE);
	handle[1].myProCtrl = myProCtrl2;
	handle[1].pWnd      = pWnd2;
	handle[1].txt       = txt2;

	CProgressCtrl *myProCtrl3 = (CProgressCtrl *)GetDlgItem(IDC_PROGRESS3);
	myProCtrl3->ShowWindow(SW_HIDE);
	CWnd  *pWnd3 = GetDlgItem(IDC_STATIC_C3);
	CWnd  *txt3  = GetDlgItem(IDC_STATIC3);
	pWnd3->ShowWindow(SW_HIDE);
	txt3->ShowWindow(SW_HIDE);
	handle[2].myProCtrl = myProCtrl3;
	handle[2].pWnd      = pWnd3;
	handle[2].txt       = txt3;

	CProgressCtrl *myProCtrl4 = (CProgressCtrl *)GetDlgItem(IDC_PROGRESS4);
	myProCtrl4->ShowWindow(SW_HIDE);
	CWnd  *pWnd4 = GetDlgItem(IDC_STATIC_C4);
	CWnd  *txt4  = GetDlgItem(IDC_STATIC4);
	pWnd4->ShowWindow(SW_HIDE);
	txt4->ShowWindow(SW_HIDE);
	handle[3].myProCtrl = myProCtrl4;
	handle[3].pWnd      = pWnd4;
	handle[3].txt       = txt4;

	CProgressCtrl *myProCtrl5 = (CProgressCtrl *)GetDlgItem(IDC_PROGRESS5);
	myProCtrl5->ShowWindow(SW_HIDE);
	CWnd  *pWnd5 = GetDlgItem(IDC_STATIC_C5);
	CWnd  *txt5  = GetDlgItem(IDC_STATIC5);
	pWnd5->ShowWindow(SW_HIDE);
	txt5->ShowWindow(SW_HIDE);
	handle[4].myProCtrl = myProCtrl5;
	handle[4].pWnd      = pWnd5;
	handle[4].txt       = txt5;

	CProgressCtrl *myProCtrl6 = (CProgressCtrl *)GetDlgItem(IDC_PROGRESS6);
	myProCtrl6->ShowWindow(SW_HIDE);
	CWnd  *pWnd6 = GetDlgItem(IDC_STATIC_C6);
	CWnd  *txt6  = GetDlgItem(IDC_STATIC6);
	txt6->ShowWindow(SW_HIDE);
	pWnd6->ShowWindow(SW_HIDE);
	handle[5].myProCtrl = myProCtrl6;
	handle[5].pWnd      = pWnd6;
	handle[5].txt       = txt6;

	for (int loop = 0; loop < 6; loop++)
	{
		handle[loop].status    = 0;
		handle[loop].step      = 0;
	}
	m_pthreadmutex = CreateMutex( NULL, FALSE, NULL);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPcamera_streamsDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPcamera_streamsDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	
		CBitmap   bitmap;                            //定义位图
		bitmap.LoadBitmap(IDB_BITMAP_BACK);    //这个IDB_BITMAP1要自己添加
		CBrush   brush;                              
		brush.CreatePatternBrush(&bitmap);
		CBrush*   pOldBrush   =   dc.SelectObject(&brush);
		dc.Rectangle(0,0,1280,720);                  //前两个为图片起始位置，后两个为图片终点位置，实际为图片的像素大小
		dc.SelectObject(pOldBrush);
	}
	else
	{
		/*
		CPaintDC dc(this); // device context for painting
		CDialog::OnPaint();

		CRect rect;
		GetClientRect(&rect);
		//加载背景位图
		CBitmap   bitmap;                            //定义位图
		bitmap.LoadBitmap(IDB_BITMAP_BACK);    //这个IDB_BITMAP1要自己添加
		CBrush   brush;                              
		brush.CreatePatternBrush(&bitmap);
		CBrush*   pOldBrush   =   dc.SelectObject(&brush);
		dc.Rectangle(0,0,1280,720);                  //前两个为图片起始位置，后两个为图片终点位置，实际为图片的像素大小
		dc.SelectObject(pOldBrush);*/
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPcamera_streamsDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CPcamera_streamsDlg::OnOK() 
{
	// TODO: Add extra validation here
	printf("propath = %s\n", propath);
	zlog_info(zc, "CPcamera_streamsDlg::OnOK()");
	if (ok_status == 1)
		return;	

	CString str_ip;
	CString str_id;
	CString str_port;
	CString str_pos;  
	CString str_logopath;
	CString str_debug;

	char config_full_path[512] = {0};
	sprintf(config_full_path, "%s/config.ini", propath);

	if (IsPathExist(config_full_path))
	{
		GetPrivateProfileString("PRO", "id", "Error", str_id.GetBuffer(20), 20, config_full_path);
		GetPrivateProfileString("PRO", "ip", "Error", str_ip.GetBuffer(20), 20, config_full_path);
		GetPrivateProfileString("PRO", "port", "Error", str_port.GetBuffer(20), 20, config_full_path);
		GetPrivateProfileString("PRO", "logo_path", "Error", str_logopath.GetBuffer(20), 20, config_full_path);
		GetPrivateProfileString("PRO", "pos", "Error", str_pos.GetBuffer(20), 20, config_full_path);		
		GetPrivateProfileString("PRO", "debug", "Error", str_debug.GetBuffer(20), 20, config_full_path);

		str_ip = GetHostbyName(str_ip);

		pos = atoi(str_pos);
		isdebug = atoi(str_debug);
		logo_path = str_logopath;
	}
	else
	{
		//GetDlgItem(IDC_EDIT1)->GetWindowText(str_id);
		//GetDlgItem(IDC_EDIT2)->GetWindowText(str_ip);  		
		//GetDlgItem(IDC_EDIT3)->GetWindowText(str_port);
		//pos = ((CButton *)GetDlgItem(IDC_RADIO1))->GetCheck();
	}
	
	strcpy(server_ip, str_ip);	
	server_port = atoi(str_port);
	server_id = atoi(str_id);
	zlog_info(zc, "server_id = %d", server_id);
	if (server_id == 0)
	{
		MessageBox("请输入推流服务器ID"); 
		return;
	}

	if (isdebug > 0)
	    InitConsoleWindow();//打开日志
	ok_status = 1;
	info_thread_quit = 0;
	infohd = CreateThread(NULL, 0, get_camera_info, NULL, 0, NULL);
	//get_camera_info();
	SetTimer(1,20000,NULL);	
	SetTimer(2,50,NULL);		
}

void CPcamera_streamsDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	/*
	struct stream_info *info  = NULL;
    struct stream_info *_info = NULL;
	list_for_each_entry_safe(struct stream_info, info, _info, &task_list, list)
    {
         if (info->status == 1 && info->pi != NULL)
		 {
			 zlog_info(zc, "stop .... stream_id = %s", info->stream_id);
			 killProcess(info->pi);			 
			 info->status = 0;
			 info->threadexit = 1;
			 WaitForSingleObject(info->threadhd,1000);  
			 CloseHandle(info->threadhd);
			 CloseHandle(info->readfd);
			 list_del(&info->list);
			 if(info != NULL)
			 {
				free(info);
				info = NULL;
			 }
		 }
    }
	*/
	system("taskkill /F /IM ffmpeg.exe");
	system("taskkill /F /IM p2p.exe");
	KillTimer(1);
	KillTimer(2);
	CDialog::OnCancel();
}


void CPcamera_streamsDlg::OnEnChangeEdit1()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialog::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。
	
	// TODO:  在此添加控件通知处理程序代码
}


void CPcamera_streamsDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	static int i = 0;
	int loop = 0;

	struct stream_info *info  = NULL;
	struct stream_info *_info = NULL;

	switch(nIDEvent)//nIDEvent 为定时器事件ID，1，2，3  
	{     
	case 1: 
		//get_camera_info();
		break;  
	case 2:  
		WaitForSingleObject(m_pthreadmutex,INFINITE);
		/*
		list_for_each_entry_safe(struct stream_info, info, _info, &task_list, list)
		{
			
			if (info->status == 1 && info->handle != NULL)
			{				
				info->handle->myProCtrl->ShowWindow(SW_SHOW);
				info->handle->pWnd->ShowWindow(SW_SHOW);
				info->handle->txt->ShowWindow(SW_SHOW);
				info->handle->txt->SetWindowText(info->stream_id);
				info->handle->myProCtrl->SetRange(0,100);     
				info->handle->myProCtrl->SetPos(info->handle->step);

				info->handle->step ++;
				if (info->handle->step == 100)
					info->handle->step = 0;
			}
			
		}
		*/
		for (;loop < 6; loop++)
		{
			if (handle[loop].status == 1)
			{
				//printf("handle[loop].str = %s\n", handle[loop].str);
				handle[loop].myProCtrl->ShowWindow(SW_SHOW);
				handle[loop].pWnd->ShowWindow(SW_SHOW);
				handle[loop].txt->ShowWindow(SW_SHOW);
				handle[loop].txt->SetWindowText(handle[loop].str);
				handle[loop].myProCtrl->SetRange(0,100); 
				handle[loop].myProCtrl->SetPos(handle[loop].step);
				handle[loop].step ++;
				if (handle[loop].step == 100)
					handle[loop].step = 0;
			}
			else
			{
				handle[loop].myProCtrl->ShowWindow(SW_HIDE);
				handle[loop].pWnd->ShowWindow(SW_HIDE);
				handle[loop].txt->ShowWindow(SW_HIDE);
			}
		}
		ReleaseMutex(m_pthreadmutex);
		break;  
	}  

	CDialog::OnTimer(nIDEvent);
}


//void CPcamera_streamsDlg::OnBnClickedCancel()
//{
//	// TODO: 在此添加控件通知处理程序代码
//	//KillTimer(1);   
//	CDialog::OnCancel();
//}


//void CPcamera_streamsDlg::OnBnClickedOk()
//{
//	// TODO: 在此添加控件通知处理程序代码
//	CDialog::OnOK();
//}


void CPcamera_streamsDlg::OnBnClickedYes()
{
	// TODO: 在此添加控件通知处理程序代码
	zlog_info(zc, "CPcamera_streamsDlg::Onyes()");
	ok_status = 0;
	struct stream_info *info  = NULL;
    struct stream_info *_info = NULL;
	KillTimer(1);
	KillTimer(2);
	WaitForSingleObject(m_pthreadmutex,INFINITE);
	list_for_each_entry_safe(struct stream_info, info, _info, &task_list, list)
    {
         if (info->status == 1 && info->pi != NULL)
		 {
			 DWORD processId = info->pid;
			 zlog_info(zc, "stop .... stream_id = %s", info->stream_id);
			 handle[info->handle_num].status = 0;
			 kill_process(processId);
			 //killProcess(info->pi);
			 //system("taskkill /F /IM ffmpeg.exe");
			 info->status = 0;
			 info->threadexit = 1;
			 WaitForSingleObject(info->threadhd,1000);  
			 CloseHandle(info->threadhd);
			 CloseHandle(info->readfd);
			 //if (info->handle != NULL)
			 //{
			//	 info->handle->status = 0;
			//	 info->handle = NULL;
			 //}
			 list_del(&info->list);
			 if(info != NULL)
			 {
				free(info);
				info = NULL;
			 }
		 }
    }
	ReleaseMutex(m_pthreadmutex);
	stream_nums = 0;
	info_thread_quit = 1;
	WaitForSingleObject(infohd,100);  
	CloseHandle(infohd);
	system("taskkill /F /IM ffmpeg.exe");

	CPcamera_streamsDlg::OnOK();
}

vector<CString> files;
void GetFileFromDir(CString csDirPath)
{
	csDirPath += "\\*.png";	
	HANDLE file;
	WIN32_FIND_DATA fileData;
	char line[1024];
	char fn[1000];//mbstowcs(fn,csDirPath.GetBuffer(),999);
	file = FindFirstFile(csDirPath.GetBuffer(), &fileData);
	files.push_back(fileData.cFileName);
	CString a;
	a = fileData.cFileName;
	BOOL bState = false;
	bState = FindNextFile(file, &fileData);
	while(bState)
	{
		files.push_back(fileData.cFileName);
		a = fileData.cFileName;
		//MessageBox(a);
		bState = FindNextFile(file,&fileData);
	}
}

CString strFilePath;
void CPcamera_streamsDlg::OnBnClickedYes2()
{
	/*
	LPITEMIDLIST rootLoation;
	SHGetSpecialFolderLocation( NULL, CSIDL_DESKTOP, &rootLoation );
	if ( rootLoation == NULL ) {
		return;
	}
	BROWSEINFO bi;
	ZeroMemory( &bi, sizeof( bi ) );
	bi.pidlRoot = rootLoation;
	bi.lpszTitle = _T( "选择logo文件" );
	LPITEMIDLIST targetLocation = SHBrowseForFolder( &bi );
	TCHAR targetPath[ MAX_PATH ];
	if ( targetLocation != NULL )
	{
		//SHGetPathFromIDList( targetLocation, targetPath );
		MessageBox( targetPath );
	}
	//strFilePath.Format(_T("%s"),targetPath);
	//GetFileFromDir(strFilePath);
	
	CString strFile = _T("");
    CFileDialog    dlgFile(TRUE, NULL, NULL, OFN_HIDEREADONLY, _T("Describe Files (*.png)|*.png|All Files (*.*)|*.*||"), NULL);
    if (dlgFile.DoModal())
    {
        strFile = dlgFile.GetPathName();
		SetDlgItemText(IDC_EDIT4,strFile);
		UpdateData(FALSE);
		logo_path = strFile;
    }
	*/
	zlog_info(zc, "net test ... %s", server_ip);
	int res = CheckNetIsOK(server_ip);
	if (res > 0)
		MessageBox("网络正常");
	else
		MessageBox("网络异常");
}

BOOL CPcamera_streamsDlg::OnEraseBkgnd(CDC *pDC)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
 
  	//背景图片
	//获得客户区尺寸
	CRect rect;
	GetClientRect(&rect);
	//加载背景位图
	CBitmap bmpBackground;
	bmpBackground.LoadBitmap(IDB_BITMAP_BACK); //图片ID
 
	BITMAP bitmap;   
 
	bmpBackground.GetBitmap(&bitmap); 
	//选择位图
	//创建内存DC
	CDC dc;
	dc.CreateCompatibleDC(pDC);
 
	CBitmap* pOldBitmap=dc.SelectObject(&bmpBackground);
	//绘制位图
	SetStretchBltMode(pDC->m_hDC,STRETCH_HALFTONE);//设置指定设备环境中的位图拉伸模式。
	pDC->StretchBlt(0,0,rect.Width(),rect.Height(),&dc,0,0,bitmap.bmWidth,bitmap.bmHeight,SRCCOPY);
	//恢复原有位图
	dc.SelectObject(pOldBitmap);

    return TRUE;
}

