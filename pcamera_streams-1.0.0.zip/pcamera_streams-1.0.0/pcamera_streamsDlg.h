// pcamera_streamsDlg.h : header file
//

#if !defined(AFX_PCAMERA_STREAMSDLG_H__BB79352A_048B_4F1C_BA0E_046FA6F8B392__INCLUDED_)
#define AFX_PCAMERA_STREAMSDLG_H__BB79352A_048B_4F1C_BA0E_046FA6F8B392__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPcamera_streamsDlg dialog

class CPcamera_streamsDlg : public CDialog
{
// Construction
public:
	CPcamera_streamsDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CPcamera_streamsDlg)
	enum { IDD = IDD_PCAMERA_STREAMS_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPcamera_streamsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CPcamera_streamsDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeEdit1();
	int m_server_id;
	int ok_status;
	afx_msg void OnTimer(UINT_PTR nIDEvent);
//	afx_msg void OnBnClickedCancel();
//	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedYes();
	afx_msg void OnBnClickedYes2();	
	afx_msg BOOL OnEraseBkgnd(CDC *pDC); 

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PCAMERA_STREAMSDLG_H__BB79352A_048B_4F1C_BA0E_046FA6F8B392__INCLUDED_)
