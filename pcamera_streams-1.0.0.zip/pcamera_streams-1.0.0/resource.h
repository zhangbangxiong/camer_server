//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by pcamera_streams.rc
//
#define IDYES2                          7
#define ID_NETTEST                      8
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PCAMERA_STREAMS_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP_LOGO                 132
#define IDB_BITMAP_BACK                 134
#define IDI_ICON3                       137
#define IDI_ICON4                       138
#define IDI_ICON5                       139
#define IDI_ICON6                       140
#define IDI_ICON7                       141
#define IDI_ICON8                       142
#define IDC_EDIT1                       1000
#define IDC_PROGRESS1                   1001
#define IDC_EDIT2                       1002
#define IDC_EDIT3                       1003
#define IDC_EDIT4                       1004
#define IDC_CHECK1                      1006
#define IDC_RADIO1                      1007
#define IDC_RADIO2                      1008
#define IDC_PROGRESS2                   1009
#define IDC_PROGRESS3                   1010
#define IDC_PROGRESS4                   1011
#define IDC_PROGRESS5                   1012
#define IDC_PROGRESS6                   1013
#define IDC_STATIC_C1                   1016
#define IDC_STATIC_C2                   1017
#define IDC_STATIC_C3                   1018
#define IDC_STATIC_C4                   1019
#define IDC_STATIC_C5                   1020
#define IDC_STATIC_C6                   1021
#define IDC_STATIC1                     1022
#define IDC_STATIC2                     1023
#define IDC_STATIC3                     1024
#define IDC_STATIC4                     1025
#define IDC_STATIC5                     1026
#define IDC_STATIC6                     1027
#define IDC_BUTTON3                     1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
