#include <mysql/mysql.h>
#include "util.h"

const char *g_host_name = "27.223.92.102";
const char *g_user_name = "root";
const char *g_password 	= "123456";
const char *g_db_name 	= "bpls";
const unsigned int g_db_port = 43306;

int get_camero_status(char *path, char *stream_id)
{
        struct stat buf;
        int  result = 0;
        char file[255] = {0};

        sprintf(file, "%s/%s.log", path, stream_id);
        if (access(file, F_OK) == -1)
        {
               dzlog_info("file %s is not exist", path);
               return -1;
        }

        result = stat(file, &buf);
        if ( result != 0 )
        {
                return -2;
        }
        else
        {
                long long now_time = _gettime_s();
                if (now_time - buf.st_atime < 30)
                        return 0;
                int dif_time = _gettime_s() - buf.st_mtime;
                if (dif_time < 5)
                        return 1;
                else
                        return 0;
        }
}

int read_mysql()
{
	MYSQL *g_conn; 
	MYSQL_ROW g_row; 
	MYSQL_RES *g_res;
   	g_conn = mysql_init(NULL);

    /* connect the database */
    if(!mysql_real_connect(g_conn, g_host_name, g_user_name, g_password, g_db_name, g_db_port, NULL, 0))
	{
		printf("mysql connect failed\n");
		exit(1);
	}

	while (1)
	{
		char select_sql[64] = {0};
		sprintf(select_sql, "select * from bpls_camera where stream_machine_id=%s", server_id);
    	if (executesql(g_conn, select_sql))
        	printf("select error\n");

    	g_res = mysql_store_result(g_conn); // �ӷ��������ͽ���������أ�mysql_use_resultֱ��ʹ�÷������ϵļ�¼��

    	int iNum_rows = mysql_num_rows(g_res); // �õ���¼������
    	int iNum_fields = mysql_num_fields(g_res); // �õ���¼������

    	while ((g_row=mysql_fetch_row(g_res))) // ��ӡ�����
		{
			printf("+++%s\n", (g_row[9]));
			if (atoi(g_row[9]) == 1)
			{
				int status = 0;

                struct stream_info *info  = NULL;
                struct stream_info *_info = NULL;

                pthread_mutex_lock(&infomtx);
                list_for_each_entry_safe(info, _info, &task_list, list)
                {
					printf("info->stream_id = %s\n", info->stream_id);
					printf("g_row[0] = %s\n", g_row[0]);
                    if (atoi(info->stream_id) == atoi(g_row[0]))
					{
						status = 1;
						break;
					}
                }
                pthread_mutex_unlock(&infomtx);

				if (status)
					continue;

                struct stream_info *stream_news = NULL;
                stream_news = (struct stream_info *)malloc(sizeof(struct stream_info));
				memset(stream_news->stream_id, 0, sizeof(stream_news->stream_id));
                memcpy(stream_news->stream_id, g_row[0], strlen(g_row[0]));
				memset(stream_news->logo, 0, sizeof(stream_news->logo));
                memcpy(stream_news->logo, "nologo", 6);
				memset(stream_news->width, 0, sizeof(stream_news->width));
                memcpy(stream_news->width, g_row[13], strlen(g_row[13]));
				memset(stream_news->height, 0, sizeof(stream_news->height));
                memcpy(stream_news->height, g_row[14], strlen(g_row[14]));
                memcpy(stream_news->protocol, g_row[4], strlen(g_row[4]));
                memcpy(stream_news->bitrate, g_row[10], strlen(g_row[10]));
                memcpy(stream_news->encode, g_row[12], strlen(g_row[12]));
				memset(stream_news->in_stream_addr, 0, sizeof(stream_news->in_stream_addr));
                memcpy(stream_news->in_stream_addr, g_row[3], strlen(g_row[3]));
				memset(stream_news->out_stream_addr, 0, sizeof(stream_news->out_stream_addr));
                memcpy(stream_news->out_stream_addr, g_row[6], strlen(g_row[6]));

                printf("stream_news->in_stream_addr  = %s\n", stream_news->in_stream_addr);
                printf("stream_news->out_stream_addr = %s\n", stream_news->out_stream_addr);
                printf("stream_news->logo            = %s\n", stream_news->logo);
                printf("id = %d, info->height = %s\n",atoi(stream_news->stream_id), stream_news->height);
                pthread_mutex_lock(&infomtx);
                stream_news->status = 1;
                list_add_tail(&stream_news->list, &task_list);
                pthread_cond_signal(&infocond);
                pthread_mutex_unlock(&infomtx);
			}
			else
			{
                struct stream_info *info  = NULL;
                struct stream_info *_info = NULL;

                pthread_mutex_lock(&infomtx);
                list_for_each_entry_safe(info, _info, &task_list, list)
                {
                	if (strcmp(info->stream_id, g_row[0]) == 0)
                   	    info->status = 0;
                }
                pthread_mutex_unlock(&infomtx);
			}

		}

    	mysql_free_result(g_res); // �ͷŽ����
		sleep(3);
	}

    mysql_close(g_conn); // �ر�����

	return 0;
}

int run_command(struct stream_info *info, char *argv, char *outfile, int *timelen, int *video_width, int *video_height)
{
	FILE *fp = NULL;
	char line[1024] = {0};
	
	dzlog_info("[%s] : %s", info->stream_id, argv);

	fp=popen(argv, "r");
	if (fp == NULL)
	{
		dzlog_info("run_command error\n");
		//�쳣����
		return -1;
	}
	else
    {
         while(fgets(line, 1024, fp) != NULL)
         {
			if(strstr(line, "codec_error") != NULL)
			break;
         }
         pclose(fp);
    }

	return 0;
}

#define CODEC_VIDEO_STRING_0  "%s %s %s %s %s %s %s %s %d %s %s %s %s"
#define CODEC_JPEG_STRING   "%s -i %s -o %s -n 20 -@ %s"
#define TSCUT_STRING        "%s -i %s -d 10 -o %s -s %s -d 10 -x %s"
void *start_gome_transcoder(void *params)
{
    char  argv[INPUT_BUFFER_SIZE]    = {0};
    char  outfile[BUFFER_SIZE]       = {0};
    char  outfullfile[NOMARL_BUFFER_SIZE]    = {0};

	int   video_time_lenth = 0;
	int   video_width      = 0;
	int   video_height     = 0;
	struct stream_info *info = NULL;

	if(params != NULL)
	{
		info = (struct stream_info *)params;
	}
	else
	{
		goto EXIT;
	}

	char log_path[256] = {0};
	sprintf(log_path, "%s/%s.log", _config.log_path,info->stream_id);
		
	memset(outfullfile, 0, NOMARL_BUFFER_SIZE);
	memset(outfile, 0, BUFFER_SIZE);
	memset(argv, 0, INPUT_BUFFER_SIZE);

	printf("info->stream_id = %s\n", info->stream_id);
    snprintf(argv, INPUT_BUFFER_SIZE, CODEC_VIDEO_STRING_0, 
		_config.sh, 		_config.ffmpeg, info->in_stream_addr, 
		info->protocol, 	info->encode, 	info->bitrate,
		info->width, 		info->height, 	0, 
		info->out_stream_addr,	info->logo, 	_config.log_path,
		info->stream_id);

	/*********************************************************
 			start codec
	********************************************************/
	run_command(info, argv, outfile, &video_time_lenth, &video_width, &video_height);

EXIT:
	info->status = 0;
	pthread_mutex_lock(&threadsmtx);
	thread_nums --;
    pthread_mutex_unlock(&threadsmtx);
	pthread_exit(0);  
}