#include <stdarg.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>

#define MD5_LEN			36
#define	LEN_EVENTID		64
#define	LEN_PARAM		64
#define	LEN_OBDID		32
#define	LEN_TOKEN		128
#define	LEN_VIDEO		128
#define MAX_BUFFER_SZIE 1024*1024

#define INPUT_BUFFER_SIZE 1024
#define NOMARL_BUFFER_SIZE 256
#define BUFFER_SIZE 128
#define DATA_SIZE 512

typedef struct stream_info
{
	struct list_head list;
	char sh[b_len];
	char stream_id[b_len];
	char stream_name[b_len];
	char out_stream_addr[b_len];
	char in_stream_addr[b_len];
	char protocol[s_len];
	char logo[b_len];
	char encode[s_len];
	int  hasaudio;
	char  bitrate[s_len];
	char  frame_rate[s_len];
	char  width[s_len];
	char  height[s_len];
	int  status;
	pthread_t thread_id;
}STREAMINFO;

typedef struct Config{
    char id[16];
    char ffmpeg[b_len];
    char sh[b_len];
    char kill_sh[b_len];
    char log_path[b_len];
}config_t;

void configure(struct Config *config);
void *start_gome_transcoder(void *params);
int read_mysql();
int get_camero_status(char *path, char *stream_id);