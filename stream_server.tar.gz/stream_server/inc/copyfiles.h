#ifndef _COPY_FILES_H_
#define _COPY_FILES_H_

int copyfiles(void* data);

#endif
