#ifndef  _GET_PATH_H
#define  _GET_PATH_H
/*
 *vid:  video id
 *
 * return: file path
 */
char* getpath(int vid);

#endif
