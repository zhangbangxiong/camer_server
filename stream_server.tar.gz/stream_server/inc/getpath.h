#ifndef  _GET_PATH_H
#define  _GET_PATH_H
/*
 *vid:  video id
 *
 * return: file path
 */
int get_path(int vid, char *res);

#endif
