#ifndef _HTTP_POST_MSG_H_
#define _HTTP_POST_MSG_H_

int send_msg(char *ip, int port, char *data, char *res);

#endif
