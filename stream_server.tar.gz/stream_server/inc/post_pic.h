#ifndef _UPLOAD_PIC_H_
#define _UPLOAD_PIC_H_

extern "C" int upload_pic(char*ip, int port, char* path, int id, char* image1, char* image2);

#endif
